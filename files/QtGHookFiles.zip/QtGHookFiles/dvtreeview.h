#ifndef DVTREEVIEW_H
#define DVTREEVIEW_H
#include <QTreeView>
#include <QMouseEvent>
class DVTreeView : public QTreeView
{
    Q_OBJECT
public:
    DVTreeView(QWidget *parent = 0);

signals:
    void mouseReleased(QMouseEvent *e);

protected:
    void mouseReleaseEvent(QMouseEvent * event);
};

#endif // DVTREEVIEW_H
