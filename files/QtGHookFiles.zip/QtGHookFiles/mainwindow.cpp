#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "dvtreeview.h"
#include <QDir>
#include <QMessageBox>
#include <QPainter>
#include <QRect>
#include <QTimer>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    fileModel(new QFileSystemModel),
    pressedModelIndex(0), enteredModelIndex(0)
{
    ui->setupUi(this);

    QString playgroundPath = QDir::currentPath() + "/Playground";
    fileModel->setRootPath(playgroundPath);

    DVTreeView *treeView = ui->treeView;

    treeView->setModel(fileModel.data());
    treeView->setRootIndex(fileModel->index(playgroundPath));
    fileModel->setReadOnly(true);

    //Config treeview style
    treeView->header()->resizeSection(0, 160);
    treeView->header()->setSectionHidden(2, true);
    treeView->header()->setSectionHidden(3, true);
    treeView->expandAll();
    //FileModel at this time hasn't all the data...QTimer will call a delayed SLOT
    //QTimer::singleShot(100, [=]() { treeView->expandAll(); } );
    //lambda expressions not available...not C++11
    //workaround, using slots;
    QTimer::singleShot(100, this, ExpandTreeView);

    //Set connects
    connect(treeView, SIGNAL(pressed(const QModelIndex &)),
            this, SLOT(TreeViewIndexPressed(const QModelIndex &)));
    connect(treeView, SIGNAL(entered(const QModelIndex &)),
            this, SLOT(TreeViewIndexEntered(const QModelIndex &)));
    connect(treeView, SIGNAL(mouseReleased(QMouseEvent *)),
            this, SLOT(TreeViewMouseReleased(QMouseEvent *)));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::TreeViewIndexPressed(const QModelIndex & index)
{
    pressedModelIndex = &index;
    enteredModelIndex = 0;
    this->repaint();
}

void MainWindow::TreeViewIndexEntered(const QModelIndex & index)
{
    enteredModelIndex = pressedModelIndex != &index ? &index : 0;
    this->repaint();
}

void MainWindow::TreeViewMouseReleased(QMouseEvent *e)
{
    this->repaint();
    if (e->button() != Qt::LeftButton || !pressedModelIndex  || !enteredModelIndex)
        return;
}

void MainWindow::ExpandTreeView()
{
    ui->treeView->expandAll();
}

//overring
void MainWindow::keyPressEvent(QKeyEvent *e)
{
    if(e->key() != Qt::Key_Shift || !pressedModelIndex || !enteredModelIndex )
    {
        //no action upon key, call base class implementation
        QMainWindow::keyPressEvent(e);
        return;
    }

    bool pressedIsDir = fileModel->isDir(*pressedModelIndex);
    bool releasedIsDir = fileModel->isDir(*enteredModelIndex);

    if(pressedIsDir && releasedIsDir)
    {
        QMessageBox::information(this, "Error", "Cannot pull two directories together");
        return;
    }

    int pressedSize = fileModel->size(*pressedModelIndex);
    int releasedSize = fileModel->size(*enteredModelIndex);

    QString srcPath = pressedIsDir ? fileModel->filePath(*enteredModelIndex) :
                      releasedIsDir ? fileModel->filePath(*pressedModelIndex) :
                      pressedSize > releasedSize ? fileModel->filePath(*enteredModelIndex) :
                      fileModel->filePath(*pressedModelIndex);

    QString targetPath = srcPath == fileModel->filePath(*pressedModelIndex) ?
                         fileModel->filePath(*enteredModelIndex) :
                         fileModel->filePath(*pressedModelIndex);

    //If target path is not a directory already, move up from file path to its directory
    if(!QDir(targetPath).exists())
    {
        QDir tmpDir(targetPath);
        tmpDir.cdUp();
        targetPath = tmpDir.path();
    }

    //Move file
    QDir srcDir(srcPath);
    QString srcFileName = srcDir.dirName();
    targetPath += "/" + srcFileName;

    //Don't move to the same folder
    if(srcPath == targetPath)
    {
        QMessageBox::information(this, "Error", "Already in the same folder");
        return;
    }
    //Try to mode using 'rename'
    if(!srcDir.rename(srcPath, targetPath))
    {
         QMessageBox::information(this, "Error", "Fail to move: \"" + srcPath +
                                  "\" to \"" + targetPath + "\"");
    }

    //Reset pointers
    pressedModelIndex = 0;
    enteredModelIndex = 0;
    this->repaint();
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    QMainWindow::paintEvent(event);

    QPainter painter(this);
    painter.setPen(Qt::NoPen);
    painter.setBrush(Qt::black);

    QRect defaultNodeRect(20, ui->treeView->y() + 40, 10, 10);
    QRect defaultLineRect(defaultNodeRect.x() + 3,
                          defaultNodeRect.y(),
                          4, 10);
    //Draw Pressed Node
    if(pressedModelIndex)
    {
       QRect rect(defaultNodeRect);
       rect.moveTo(rect.x(), rect.y() + ui->treeView->visualRect(*pressedModelIndex).y());
       painter.drawRect(rect);
    }

    //Draw Entered Node and Line
    if(enteredModelIndex)
    {
        int pressedNodeY = ui->treeView->visualRect(*pressedModelIndex).y();
        int enteredNodeY = ui->treeView->visualRect(*enteredModelIndex).y();

        //Entered Node
        QRect rect(defaultNodeRect);
        rect.moveTo(defaultNodeRect.x(), defaultNodeRect.y() + enteredNodeY);
        painter.drawRect(rect);
        //Line
        QRect rectLine(defaultLineRect);
        rectLine.setTop((pressedNodeY > enteredNodeY ? enteredNodeY : pressedNodeY)
                        + defaultLineRect.y());
        rectLine.setBottom((pressedNodeY > enteredNodeY ? pressedNodeY : enteredNodeY)
                           + defaultLineRect.y());
        painter.drawRect(rectLine);

        //Shift Text
        painter.setPen(Qt::black);
        painter.rotate(-90);
        painter.drawText(-rectLine.bottom(),
                         defaultNodeRect.x() - 4,
                         "Press Shift to Pull");
    }

    painter.end();
}
