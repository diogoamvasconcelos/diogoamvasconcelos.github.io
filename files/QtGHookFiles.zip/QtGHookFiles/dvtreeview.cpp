#include "dvtreeview.h"

DVTreeView::DVTreeView(QWidget *parent) : QTreeView(parent)
{

}

void DVTreeView::mouseReleaseEvent(QMouseEvent *event)
{
    QTreeView::mouseReleaseEvent(event);
    emit mouseReleased(event);
}
