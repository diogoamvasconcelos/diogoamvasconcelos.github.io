#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QSharedPointer>
#include <QMainWindow>
#include <QFileSystemModel>
#include <QKeyEvent>
#include <QMouseEvent>
#include <QPaintEvent>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void TreeViewIndexPressed(const QModelIndex & index);
    void TreeViewIndexEntered(const QModelIndex & index);
    void TreeViewMouseReleased(QMouseEvent *e);
    void ExpandTreeView();

protected:
    void keyPressEvent(QKeyEvent *e);
    void paintEvent(QPaintEvent *event);

private:
    Ui::MainWindow *ui;
    QSharedPointer<QFileSystemModel> fileModel;
    const QModelIndex *pressedModelIndex;
    const QModelIndex *enteredModelIndex;
};

#endif // MAINWINDOW_H
